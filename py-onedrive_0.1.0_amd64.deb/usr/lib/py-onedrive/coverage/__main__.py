# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://github.com/coveragepy/coveragepy/blob/main/NOTICE.txt

"""Coverage.py's main entry point."""

from __future__ import annotations

import sys

from coverage.cmdline import main

sys.exit(main())
